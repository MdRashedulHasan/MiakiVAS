-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Feb 25, 2017 at 03:27 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miaki_laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(6, '2014_10_12_000000_create_users_table', 1),
(7, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2017_01_10_064227_create_testusers_table', 1),
(9, '2017_01_14_070939_create_myuser_table', 2),
(18, '2017_01_16_074833_create_myuser_admin_table', 3),
(19, '2017_01_16_074918_create_emp_att_table', 3),
(20, '2017_01_16_075001_create_leave_app_table', 3),
(21, '2017_01_16_075039_create_leave_statistic_table', 3),
(22, '2017_01_16_075138_create_leave_approval_table', 3),
(23, '2017_01_16_075213_create_leave_type_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category` varchar(150) NOT NULL,
  `partner` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `published` varchar(20) NOT NULL,
  `featured` varchar(20) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(200) NOT NULL,
  `file` text,
  `thumbnail` text,
  `remember_token` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `category`, `partner`, `description`, `published`, `featured`, `price`, `discount`, `file`, `thumbnail`, `remember_token`, `created_at`, `updated_at`) VALUES
(40, 'Oju_P3', 'Audio', 'Spondon', 'Younger Muslims argued that the Meccans were destroying crops, and huddling in the strongholds would destroy Muslim prestige. Muhammad eventually conceded to the younger Muslims and readied the Muslim force for battle.', 'Yes', 'No', '2.00', '0%', 'file10.docx', 'oju3.jpg', NULL, '2017-02-25 09:16:12', '2017-02-25 09:16:12'),
(39, 'Oju_P2', 'Audio', 'Spondon', 'Younger Muslims argued that the Meccans were destroying crops, and huddling in the strongholds would destroy Muslim prestige. Muhammad eventually conceded to the younger Muslims and readied the Muslim force for battle.', 'Yes', 'No', '2.00', '0%', 'file9.docx', 'oju2.jpg', NULL, '2017-02-25 09:15:14', '2017-02-25 09:15:14'),
(38, 'Oju_P1', 'Audio', 'Spondon', 'Younger Muslims argued that the Meccans were destroying crops, and huddling in the strongholds would destroy Muslim prestige. Muhammad eventually conceded to the younger Muslims and readied the Muslim force for battle.', 'Yes', 'No', '2.00', '0%', 'file8.docx', 'oju1.jpg', NULL, '2017-02-25 09:13:33', '2017-02-25 09:13:33'),
(37, 'Namaz Shikkha 03', 'Video', 'ILM', 'Younger Muslims argued that the Meccans were destroying crops, and huddling in the strongholds would destroy Muslim prestige. Muhammad eventually conceded to the younger Muslims and readied the Muslim force for battle.', 'Yes', 'No', '2.00', '0%', 'file7.docx', 'salar03.png', NULL, '2017-02-25 09:11:54', '2017-02-25 09:11:54'),
(36, 'Namaz Shikkha 02', 'Video', 'ILM', 'A scout alerted Muhammad of the Meccan army\'s presence and numbers a day later. The next morning, at the Muslim conference of war, dispute arose over how best to repel the Meccans. Muhammad and many senior figures suggested it would be safer to fight within Medina and take advantage of the heavily fortified strongholds.', 'Yes', 'Yes', '2.00', '0%', 'file6.docx', 'salat02.jpg', NULL, '2017-02-25 09:10:41', '2017-02-25 09:10:41'),
(35, 'Namaz Shikkha 01', 'Video', 'ILM', 'Muhammad and many senior figures suggested it would be safer to fight within Medina and take advantage of the heavily fortified strongholds.', 'Yes', 'Yes', '2.00', '0%', 'file5.docx', 'salat01.jpg', NULL, '2017-02-25 09:08:52', '2017-02-25 09:08:52'),
(34, 'Kaba ghorer chobi01', 'Video', 'Spondon', 'A scout alerted Muhammad of the Meccan army\'s presence and numbers a day later. The next morning, at the Muslim conference of war, dispute arose over how best to repel the Meccans. ', 'Yes', 'Yes', '2.00', '0%', 'file4.docx', 'kaba.jpg', NULL, '2017-02-25 09:06:53', '2017-02-25 09:06:53'),
(33, 'Rasul(sm) er talwar', 'Video', 'Spondon', 'A scout alerted Muhammad of the Meccan army\'s presence and numbers a day later. The next morning, at the Muslim conference of war, dispute arose over how best to repel the Meccans. Muhammad and many senior figures suggested it would be safer to fight within Medina and take advantage of the heavily fortified strongholds.', 'Yes', 'No', '2.00', '0%', 'file3.docx', 'talwar.jpg', NULL, '2017-02-25 09:05:16', '2017-02-25 09:05:16'),
(32, 'Rasul(sm) er kesh mobarok', 'Video', 'Spondon', 'A scout alerted Muhammad of the Meccan army\'s presence and numbers a day later. The next morning, at the Muslim conference of war, dispute arose over how best to repel the Meccans.', 'No', 'Yes', '2.00', '0%', 'file2.docx', 'kesh.jpg', NULL, '2017-02-25 09:03:51', '2017-02-25 09:03:51'),
(31, 'Rasul(sm) er payer chinno', 'Video', 'Spondon', 'A scout alerted Muhammad of the Meccan army\'s presence and numbers a day later. The next morning, at the Muslim conference of war, dispute arose over how best to repel the Meccans. Muhammad and many senior figures suggested it would be safer to fight within Medina and take advantage of the heavily fortified strongholds.', 'Yes', 'No', '2.00', '0%', 'file.docx', 'hqdefault.jpg', NULL, '2017-02-25 09:00:55', '2017-02-25 09:00:55');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
