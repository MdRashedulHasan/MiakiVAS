-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3307
-- Generation Time: Feb 23, 2017 at 02:19 PM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `miaki_laravel`
--

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(6, '2014_10_12_000000_create_users_table', 1),
(7, '2014_10_12_100000_create_password_resets_table', 1),
(8, '2017_01_10_064227_create_testusers_table', 1),
(9, '2017_01_14_070939_create_myuser_table', 2),
(18, '2017_01_16_074833_create_myuser_admin_table', 3),
(19, '2017_01_16_074918_create_emp_att_table', 3),
(20, '2017_01_16_075001_create_leave_app_table', 3),
(21, '2017_01_16_075039_create_leave_statistic_table', 3),
(22, '2017_01_16_075138_create_leave_approval_table', 3),
(23, '2017_01_16_075213_create_leave_type_table', 3);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(200) NOT NULL,
  `category` varchar(150) NOT NULL,
  `partner` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `published` varchar(20) NOT NULL,
  `featured` varchar(20) NOT NULL,
  `price` varchar(100) NOT NULL,
  `discount` varchar(200) NOT NULL,
  `file` text NOT NULL,
  `thumbnail` text NOT NULL,
  `remember_token` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `category`, `partner`, `description`, `published`, `featured`, `price`, `discount`, `file`, `thumbnail`, `remember_token`, `created_at`, `updated_at`) VALUES
(3, 'Rasul(sm) er payer chinno', 'Video', 'Spondon', 'BRAZILIAN\'S BRAZILIANS BRAZILS BRAZOS BRAZZA BRDA BRE BRE\'ER ...... CHINNOOK CHINNOOKS CHINNY CHINO CHINOIS CHINOISE CHINOISES ...... PAYCHECK PAYDAY PAYDERSON PAYE PAYED PAYEE PAYEN PAYER ...... RASTIGNAC RASTIGNAC\'S RASTLE RASTLIN RASTRO RASTUS RASU', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php3F69.tmp', 'E:\\wamp\\tmp\\php3F6A.tmp', NULL, '2017-02-22 11:57:54', '2017-02-23 08:05:59'),
(4, 'Rasul(sm) er tolwar', 'Video', 'Spondon', 'This description for rasul (sm) er tolwarThis description for rasul (sm) er tolwarThis description for rasul (sm) er tolwarThis description for rasul (sm) er tolwarThis description for rasul (sm) er tolwar', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php92A.tmp', 'E:\\wamp\\tmp\\php94A.tmp', NULL, '2017-02-23 01:20:06', '2017-02-23 08:06:10'),
(5, 'Kaba ghorer chobi01', 'Video', 'Spondon', 'This description for Kaba ghorer chobidescription for Kaba ghorer chobidescription for Kaba ghorer chobidescription for Kaba ghorer chobidescription for Kaba ghorer chobi', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\phpEEDF.tmp', 'E:\\wamp\\tmp\\phpEEEF.tmp', NULL, '2017-02-23 02:41:22', '2017-02-23 08:06:27'),
(6, 'Rasul(sm) er kesh mobarok', 'Video', 'Spondon', 'This is Category descriptionThis is Category descriptionThis is Category descriptionThis is Category descriptionThis is Category description', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php9B7.tmp', 'E:\\wamp\\tmp\\php9F7.tmp', NULL, '2017-02-23 04:46:28', '2017-02-23 08:07:17'),
(7, 'Namaz Shikkha 02', 'Video', 'ILM', 'This is my Namaz Shikkha 02 Description.This is my Namaz Shikkha 02 Description.This is my Namaz Shikkha 02 Description.This is my Namaz Shikkha 02 Description.', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\phpEC4C.tmp', 'E:\\wamp\\tmp\\phpEC9B.tmp', NULL, '2017-02-23 04:54:00', '2017-02-23 08:07:07'),
(8, 'Namaz Shikkha 01', 'Video', 'ILM', 'This is description for Namaz Shikka 01This is description for Namaz Shikka 01This is description for Namaz Shikka 01This is description for Namaz Shikka 01This is description for Namaz Shikka 01', 'No', 'Yes', '2.00', '0%', 'E:\\wamp\\tmp\\phpA814.tmp', 'E:\\wamp\\tmp\\phpA853.tmp', NULL, '2017-02-23 06:26:33', '2017-02-23 08:07:39'),
(9, 'Namaz Shikkha 03', 'Video', 'ILM', 'This is Namaz Shikkha 03 Description .This is Namaz Shikkha 03.This is Namaz Shikkha 03.This is Namaz Shikkha 03.', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php63E0.tmp', 'E:\\wamp\\tmp\\php6410.tmp', NULL, '2017-02-23 08:09:09', '2017-02-23 08:09:09'),
(10, 'Oju_P3', 'Video', 'ILM', 'This is a descriptionThis is a descriptionThis is a descriptionThis is a descriptionThis is a descriptionThis is a descriptionThis is a descriptionThis is a description', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php49DD.tmp', 'E:\\wamp\\tmp\\php4A1D.tmp', NULL, '2017-02-23 08:10:08', '2017-02-23 08:10:08'),
(11, 'Oju_P2', 'Video', 'ILM', 'This is oju_p2 descriptionoju_p2 descriptionoju_p2 descriptionoju_p2 descriptionoju_p2 description', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php781E.tmp', 'E:\\wamp\\tmp\\php784E.tmp', NULL, '2017-02-23 08:11:25', '2017-02-23 08:11:25'),
(12, 'Oju_P1', 'Video', 'ILM', 'This is Oju_P1 Descriptoinis Oju_P1 Descriptoinis Oju_P1 Descriptoinis Oju_P1 Descriptoinis Oju_P1 Descriptoinis Oju_P1 Descriptoinis Oju_P1 Descriptoin', 'Yes', 'No', '2.00', '0%', 'E:\\wamp\\tmp\\php33CF.tmp', 'E:\\wamp\\tmp\\php33EF.tmp', NULL, '2017-02-23 08:12:13', '2017-02-23 08:12:13');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`),
  ADD KEY `password_resets_token_index` (`token`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
