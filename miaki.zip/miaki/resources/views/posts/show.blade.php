@extends('layouts.app')

@section('content')
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Post {{ $post->id }}</div>
                    <div class="panel-body">

                        <a href="{{ url('/posts') }}" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="{{ url('/posts/' . $post->id . '/edit') }}" title="Edit Post"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </button></a>
                        {!! Form::open([
                            'method'=>'DELETE',
                            'url' => ['posts', $post->id],
                            'style' => 'display:inline'
                        ]) !!}
                            {!! Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> ', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Post',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            ))!!}
                        {!! Form::close() !!}
                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                            <tr>
                             <th>ID</th>
                             <td>{!! $post->id !!}</td>
                            </tr>
                            <tr>
                            <th> Title </th>
                            <td> {!! $post->title !!} </td>
                            </tr>
                            <tr>
                            <th> Category </th>
                            <td> {!! $post->category !!} </td>
                            </tr>
                            <tr>
                            <th> Partner </th>
                            <td> {!! $post->partner !!} </td>
                            </tr>
                            <tr>
                            <th> Description </th>
                            <td> {!! $post->description !!} </td>
                            </tr>
                            <tr>
                            <th> Published </th>
                            <td> {!! $post->published !!} </td>
                            </tr>
                            <tr>
                            <th> Featured </th>
                            <td> {!! $post->featured !!} </td>
                            </tr>
                            <tr>
                            <th> Price </th>
                            <td> {!! $post->price !!} </td>
                            </tr>
                            <tr>
                            <th> Discount </th>
                            <td> {!! $post->discount !!} </td>
                            </tr>
                            <tr>
                            <th> Image </th>                            
                            <!-- <td>{!! $post->thumbnail !!}</td> -->
                            <td>
                                <td>{!! Html::image('uploadthumb/'.$post->thumbnail,'alt',array('width'=>150,'height'=>150)) !!}</td>
                            </td>
                            </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
