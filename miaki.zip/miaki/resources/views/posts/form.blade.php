<div class="col-md-6">
{!! Form::open(['files' => true]) !!}
<div class="form-group {{ $errors->has('title') ? 'has-error' : ''}}">
    {!! Form::label('title', 'Title', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('title', null, ['class' => 'form-control','required']) !!}
        {!! $errors->first('title', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('category') ? 'has-error' : ''}}">
    {!! Form::label('category', 'Category', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {{ Form::select('category', [
   '' => 'Select a category',
   'Video' => 'Video',
   'Audio' => 'Audio']) }}
        {!! $errors->first('category', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('partner') ? 'has-error' : ''}}">
    {!! Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        
        {{ Form::select('partner', [
   '' => 'Select a partner',
   'Spondon' => 'Spondon',
   'ILM' => 'ILM']
) }}
        {!! $errors->first('partner', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('description') ? 'has-error' : ''}}">
    {!! Form::label('description', 'Description', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::textarea('description', null, ['class' => 'form-control']) !!}
        {!! $errors->first('description', '<p class="help-block">:message</p>') !!}
    </div>
</div>
    
</div>
<div class="col-md-6">
    
<div class="form-group {{ $errors->has('published') ? 'has-error' : ''}}">
    {!! Form::label('published', 'Published', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::radio('published', 'Yes',true) !!}Yes
        {!! Form::radio('published', 'No') !!} No
        {!! $errors->first('published', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('featured') ? 'has-error' : ''}}">
    {!! Form::label('featured', 'Featured', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::radio('featured', 'Yes') !!}Yes
        {!! Form::radio('featured', 'No',true) !!} No
        {!! $errors->first('featured', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('price') ? 'has-error' : ''}}">
    {!! Form::label('price', 'Price', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">        
        {!! Form::text('price', null, ['class' => 'form-control']) !!}
        {!! $errors->first('price', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('discount') ? 'has-error' : ''}}">
    {!! Form::label('discount', 'Discount(%)', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::text('discount', null, ['class' => 'form-control']) !!}
        {!! $errors->first('discount', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('file') ? 'has-error' : ''}}">
    {!! Form::label('file', 'File', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::file('file', null, ['class' => 'form-control']) !!}
        {!! $errors->first('file', '<p class="help-block">:message</p>') !!}
    </div>
</div>
<div class="form-group {{ $errors->has('thumbnail') ? 'has-error' : ''}}">
    {!! Form::label('thumbnail', 'Thumbnail', ['class' => 'col-md-4 control-label']) !!}
    <div class="col-md-6">
        {!! Form::file('thumbnail', null, ['class' => 'form-control']) !!}
        {!! Html::image('uploadthumb/thumbnail_icon.gif','alt',array('width'=>100,'height'=>100)) !!}
        {!! $errors->first('thumbnail', '<p class="help-block">:message</p>') !!}

    </div>
</div>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        {!! Form::submit(isset($submitButtonText) ? $submitButtonText : 'Save', ['class' => 'btn btn-primary btn-sm']) !!}
    {!! Form::button('<i class="glyphicon glyphicon-repeat">Cancel</i>',array('type' => 'button', 'class' => 'btn btn-sm btn-danger')) !!}
    </div>
</div>
    {!! Form::close() !!}

</div>