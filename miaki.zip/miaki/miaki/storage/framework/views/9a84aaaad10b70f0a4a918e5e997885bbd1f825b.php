<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<a href="create_new" class="btn btn-primary">Create</a>
<table class="table table-hover">
	<thead>
		<tr>
			<th>SI</th>
			<th>User Name</th>
			<th>Password</th>
			<th>Update</th>
			<th>Delete</th>
			<th>View</th>
		</tr>
	</thead>
	<?php echo e($i=1); ?>

	<?php $__currentLoopData = $myuser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cont): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($cont->myuser_name); ?></td>
			<td><?php echo e($cont->myuser_pass); ?></td>
			<td>
				<?php echo Form::open([
					'method'=>'DELETE',
					'route'=>['create_myuser.destroy',$cont->id]

				]); ?>


				<?php echo Form::submit('Delete',['class'=>'btn btn-danger']); ?>

				
				<?php echo Form::close(); ?>

			</td>
			<td></td>
			<td></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
	</thead>
</table>