<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/jquery.dataTables.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/jquery.dataTables.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
<button data-toggle="modal" data-target="#add_att" class="btn btn-sm btn-primary">Add+</button>
<a href="create_att" class="btn btn-primary">Create New Attendance</a>
<a href="myuser" class="btn btn-info">Users</a>
<table class="table table-stiped mydatatable">
	<?php echo e($i=1); ?>

	<thead>
		<tr>
			<th>SI</th>
			<th>Emp ID</th>
			<th>Name</th>
			<th>Date</th>
			<th>SignIn</th>
			<th>SignOut</th>
			<th>Delete</th>
			<th>Update</th>
			<th>View</th>
		</tr>
	</thead>
	
	<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($row->emp_id); ?></td>
			<td><?php echo e($row->emp_name); ?></td>
			<td><?php echo e($row->att_date); ?></td>
			<td><?php echo e($row->sign_in); ?></td>
			<td><?php echo e($row->sign_out); ?></td>
			<td>
				<?php echo Form::open([
					'method'=>'DELETE',
					'route'=>['attcont.destroy',$row->id]

				]); ?>


				<?php echo Form::submit('Delete',['class'=>'btn btn-danger btn-sm']); ?>

				
				<?php echo Form::close(); ?>

			</td>
			<td><a href="<?php echo e(route ('attcont.edit',$row->id)); ?>" class="btn btn-info btn-sm">Edit</a></td>
			<td><a href="" class="btn btn-success btn-sm">Details</a></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
<div id="add_att" class="modal fade" role="dialog">
	<div class="modal-dialog modal-md">
		<?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

			<div class="modal-content">
				<div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>					
				</div>
				<div class="modal-body">
					<table class="table table-hover" id="view_att">
						<tr>
							<th>Employee ID</th>
							<td><?php echo Form::text('emp_id','',array(
    'class'=>'form-control',
    'id'=>'emp_id',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>								
							</td>
						</tr>
    <tr><td></td> <td id="emp_id_error" style="color:red"></td></tr>
						<tr>
							<th>Employee Name</th>
							<td><?php echo Form::text('emp_name','',array(
    'class'=>'form-control',
    'id'=>'emp_name',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>								
							</td>
						</tr>
    <tr><td></td> <td id="emp_name_error" style="color:red"></td></tr>
						<tr>
							<th>Date</th>
							<td><?php echo Form::date('att_date','',array(
    'class'=>'form-control',
    'id'=>'att_date',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>								
							</td>
						</tr>
    <tr><td></td> <td id="att_date_error" style="color:red"></td></tr>
						<tr>
							<th>Sign In</th>
							<td><?php echo Form::text('sign_in','',array(
    'class'=>'form-control',
    'id'=>'sign_in',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>								
							</td>
						</tr>
    <tr><td></td> <td id="sign_in_error" style="color:red"></td></tr>
						<tr>
							<th>Sign Out</th>
							<td><?php echo Form::text('sign_out','',array(
    'class'=>'form-control',
    'id'=>'sign_out',
    'onkeyup'=>'formValidation(id)',
    'onchange'=>'formValidation(id)'
            
            )); ?>								
							</td>
						</tr>
    <tr><td></td> <td id="sign_out_error" style="color:red"></td></tr>
					</table>
				</div>

				<div class="modal-footer">
               <?php echo Form::submit('Save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

                
               <?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

               
<!--               <buttonn type="button" class="btn btn-sm btn-success" data-dismiss="modal">No</button>-->
            </div>
            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			</div>
		<?php echo Form::close(); ?>

	</div>
</div>
		</div>
	</div>
</div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('.mydatatable').DataTable();
	});

	function save_data(){
		var form=$('#save').get(0)
		var emp_id=$('input[name=emp_id]').val();
		var emp_name=$('input[name=emp_name]').val();
		var att_date=$('input[name=att_date]').val();
		var sign_in=$('input[name=sign_in]').val();
		var sign_out=$('input[name=sign_out]').val();
        var token=$('input[name=_token]').val();
        if (emp_id==""||emp_name==""||att_date==""||sign_in==""||sign_out=="") {
        	if (emp_id==="") {
        		$("#emp_id_error").html("please enter employee id");
        		$("#emp_id").css('border-color','red');
        	}
        	if (emp_name==="") {
        		$("#emp_name_error").html("please enter employee id");
        		$("#emp_name").css('border-color','red');
        	}
        	if (att_date==="") {
        		$("#att_date_error").html("please enter employee id");
        		$("#att_date").css('border-color','red');
        	}
        	if (sign_in==="") {
        		$("#sign_in_error").html("please enter employee id");
        		$("#sign_in").css('border-color','red');
        	}
        	if (sign_out==="") {
        		$("#sign_out_error").html("please enter employee id");
        		$("#sign_out").css('border-color','red');
        	}
        }else{
        	$.ajax({
        		url:'save_att',
        		method:'post',
        		data:{
        			'emp_id':emp_id,
        			'emp_name':emp_name,
        			'att_date':att_date,
        			'sign_in':sign_in,
        			'sign_out':sign_out,
        			'_token':token
        		},
        		dataType:'JSON',
        		success:function(data){
        			$('#add').modal('hide');
        			$('#view_att').html(data);
        		}
        	})
        }
	}
</script>
<script type="text/javascript">
	function formValidation(id){
		var val=$.trim($('#'+id).val());
		if (val==='') {
			$('#'+id+'_error').html('');
			$('#'+id).css('border-color','red');
		}else{
			$('#'+id+'_error').html('');
			$('#'+id).css('border-color','green');
		}
	}
</script>