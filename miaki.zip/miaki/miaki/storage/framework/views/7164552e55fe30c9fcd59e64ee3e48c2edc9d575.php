<div class="col-md-6">
<?php echo Form::open(['files' => true]); ?>

<div class="form-group <?php echo e($errors->has('title') ? 'has-error' : ''); ?>">
    <?php echo Form::label('title', 'Title', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('title', null, ['class' => 'form-control','required']); ?>

        <?php echo $errors->first('title', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('category') ? 'has-error' : ''); ?>">
    <?php echo Form::label('category', 'Category', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo e(Form::select('category', [
   '' => 'Select a category',
   'Video' => 'Video',
   'Audio' => 'Audio'])); ?>

        <?php echo $errors->first('category', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('partner') ? 'has-error' : ''); ?>">
    <?php echo Form::label('partner', 'Partner', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        
        <?php echo e(Form::select('partner', [
   '' => 'Select a partner',
   'Spondon' => 'Spondon',
   'ILM' => 'ILM']
)); ?>

        <?php echo $errors->first('partner', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('description') ? 'has-error' : ''); ?>">
    <?php echo Form::label('description', 'Description', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::textarea('description', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('description', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
    
</div>
<div class="col-md-6">
    
<div class="form-group <?php echo e($errors->has('published') ? 'has-error' : ''); ?>">
    <?php echo Form::label('published', 'Published', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::radio('published', 'Yes',true); ?>Yes
        <?php echo Form::radio('published', 'No'); ?> No
        <?php echo $errors->first('published', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('featured') ? 'has-error' : ''); ?>">
    <?php echo Form::label('featured', 'Featured', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::radio('featured', 'Yes'); ?>Yes
        <?php echo Form::radio('featured', 'No',true); ?> No
        <?php echo $errors->first('featured', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('price') ? 'has-error' : ''); ?>">
    <?php echo Form::label('price', 'Price', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">        
        <?php echo Form::text('price', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('price', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('discount') ? 'has-error' : ''); ?>">
    <?php echo Form::label('discount', 'Discount(%)', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::text('discount', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('discount', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('file') ? 'has-error' : ''); ?>">
    <?php echo Form::label('file', 'File', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::file('file', null, ['class' => 'form-control']); ?>

        <?php echo $errors->first('file', '<p class="help-block">:message</p>'); ?>

    </div>
</div>
<div class="form-group <?php echo e($errors->has('thumbnail') ? 'has-error' : ''); ?>">
    <?php echo Form::label('thumbnail', 'Thumbnail', ['class' => 'col-md-4 control-label']); ?>

    <div class="col-md-6">
        <?php echo Form::file('thumbnail', null, ['class' => 'form-control']); ?>

        <?php echo Html::image('uploadthumb/thumbnail_icon.gif','alt',array('width'=>100,'height'=>100)); ?>

        <?php echo $errors->first('thumbnail', '<p class="help-block">:message</p>'); ?>


    </div>
</div>
<div class="form-group">
    <div class="col-md-offset-4 col-md-4">
        <?php echo Form::submit(isset($submitButtonText) ? $submitButtonText : 'Save', ['class' => 'btn btn-primary btn-sm']); ?>

    <?php echo Form::button('<i class="glyphicon glyphicon-repeat">Cancel</i>',array('type' => 'button', 'class' => 'btn btn-sm btn-danger')); ?>

    </div>
</div>
    <?php echo Form::close(); ?>


</div>