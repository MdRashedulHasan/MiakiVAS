<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/datatables.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/datatables.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<h1 class="alert alert-success">Our Laravel Projects
<a href="myuser" class="btn btn-info">Login</a>
</h1>

