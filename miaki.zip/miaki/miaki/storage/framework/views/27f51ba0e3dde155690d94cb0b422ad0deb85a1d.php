<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Fish Site</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="<?php echo e(url('/css/bootstrap.min.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(url('/css/bootstrap-social.css')); ?>" rel="stylesheet"/>
<link href="<?php echo e(url('/css/font-awesome.css')); ?>" rel="stylesheet"/>
<link href="http://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(url('/css/photoswipe.css')); ?>">
<link rel="stylesheet" href="<?php echo e(url('/css/default-skin.css')); ?>">
<script src="<?php echo e(url('/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/jssor.slider-21.1.6.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/photoswipe.min.js')); ?>"></script>
<script src="<?php echo e(url('/js/photoswipe-ui-default.min.js')); ?>"></script>
<script type="text/javascript">
        jQuery(document).ready(function ($) {

            var jssor_1_SlideoTransitions = [
              [{b:-1,d:1,o:-1},{b:0,d:1000,o:1}],
              [{b:1900,d:2000,x:-379,e:{x:7}}],
              [{b:1900,d:2000,x:-379,e:{x:7}}],
              [{b:-1,d:1,o:-1,r:288,sX:9,sY:9},{b:1000,d:900,x:-1400,y:-660,o:1,r:-288,sX:-9,sY:-9,e:{r:6}},{b:1900,d:1600,x:-200,o:-1,e:{x:16}}]
            ];

            var jssor_1_options = {
              $AutoPlay: true,
              $SlideDuration: 800,
              $SlideEasing: $Jease$.$OutQuint,
              $CaptionSliderOptions: {
                $Class: $JssorCaptionSlideo$,
                $Transitions: jssor_1_SlideoTransitions
              },
              $ArrowNavigatorOptions: {
                $Class: $JssorArrowNavigator$
              },
              $BulletNavigatorOptions: {
                $Class: $JssorBulletNavigator$
              }
            };

            var jssor_1_slider = new $JssorSlider$("jssor_1", jssor_1_options);

            /*responsive code begin*/
            /*you can remove responsive code if you don't want the slider scales while window resizing*/
            function ScaleSlider() {
                var refSize = jssor_1_slider.$Elmt.parentNode.clientWidth;
                if (refSize) {
                    refSize = Math.min(refSize, 1920);
                    jssor_1_slider.$ScaleWidth(refSize);
                }
                else {
                    window.setTimeout(ScaleSlider, 30);
                }
            }
            ScaleSlider();
            $(window).bind("load", ScaleSlider);
            $(window).bind("resize", ScaleSlider);
            $(window).bind("orientationchange", ScaleSlider);
            /*responsive code end*/
        });
		$(document).ready(function(){
     $(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

});
    </script>
    <style>
        /* jssor slider bullet navigator skin 05 css */
        /*
        .jssorb05 div           (normal)
        .jssorb05 div:hover     (normal mouseover)
        .jssorb05 .av           (active)
        .jssorb05 .av:hover     (active mouseover)
        .jssorb05 .dn           (mousedown)
        */
        .jssorb05 {
            position: absolute;
        }
        .jssorb05 div, .jssorb05 div:hover, .jssorb05 .av {
            position: absolute;
            /* size of bullet elment */
            width: 16px;
            height: 16px;
            background: url('img/b05.png') no-repeat;
            overflow: hidden;
            cursor: pointer;
        }
        .jssorb05 div { background-position: -7px -7px; }
        .jssorb05 div:hover, .jssorb05 .av:hover { background-position: -37px -7px; }
        .jssorb05 .av { background-position: -67px -7px; }
        .jssorb05 .dn, .jssorb05 .dn:hover { background-position: -97px -7px; }

        /* jssor slider arrow navigator skin 22 css */
        /*
        .jssora22l                  (normal)
        .jssora22r                  (normal)
        .jssora22l:hover            (normal mouseover)
        .jssora22r:hover            (normal mouseover)
        .jssora22l.jssora22ldn      (mousedown)
        .jssora22r.jssora22rdn      (mousedown)
        .jssora22l.jssora22lds      (disabled)
        .jssora22r.jssora22rds      (disabled)
        */
        .jssora22l, .jssora22r {
            display: block;
            position: absolute;
            /* size of arrow element */
            width: 40px;
            height: 58px;
            cursor: pointer;
            background: url('img/a22.png') center center no-repeat;
            overflow: hidden;
        }
        .jssora22l { background-position: -10px -31px; }
        .jssora22r { background-position: -70px -31px; }
        .jssora22l:hover { background-position: -130px -31px; }
        .jssora22r:hover { background-position: -190px -31px; }
        .jssora22l.jssora22ldn { background-position: -250px -31px; }
        .jssora22r.jssora22rdn { background-position: -310px -31px; }
        .jssora22l.jssora22lds { background-position: -10px -31px; opacity: .3; pointer-events: none; }
        .jssora22r.jssora22rds { background-position: -70px -31px; opacity: .3; pointer-events: none; }
    </style>
  <!--<meta property="og:url" content="http://lipis.github.io/bootstrap-social/" />
    <meta property="og:image" content="http://lipis.github.io/bootstrap-social/assets/img/bootstrap-social.png" />-->
</head>

<body>
<style>
body{
	font:20px montserrat,sans-serif;
	}
p{
	font-size:16px;
	}
.margin { margin-bottom:45px;
}

.bg-0{
	background-color:#000000;
	color:#FFF;
	}
.bg-1{
	background-color:#1abc9c;
	color:#FFF;
	}
	.bg-2{
	background-color:#474e5d;
	color:#FFF;
	}	
.bg-3{
	background-color:#ffffff;
	color:#555555;
	}	
.bg-4{
	background-color:#2f2f2f;
	color:#FFF;
	}	
.bg-5{
	background-color: #DB7779;
	color:#FFF;
	}
	
.bg-6{
	background-color: #6FC5D0;
	color:#FFF;
	}	
.container-fluid{
	padding-top:70px;
	padding-bottom:70px;
	}
.navbar{
	padding-bottom:15px;
	border:0;
	border-radius:0;
	margin-bottom:0;
	font-size:12px;
	letter-spacing:5px;
	
	}
.navbar-nav li a:hover{
	color:#1abc9c !important;
	}			
	
.back-to-top {
    cursor: pointer;
    position: fixed;
    bottom: 20px;
    right: 20px;
    display:none;
}

</style>
<!-- Navbar Start -->
<nav class="navbar navbar-default">
<div class="container">
<div class="navbar-header">
<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
<span class="icon-bar"></span>
<span class="icon-bar"></span>
<span class="icon-bar"></span>
</button>
<a class="navbar-brand">Sundorban Fish</a>

</div>


<div class="collapse navbar-collapse" id="myNavbar">
<ul class="nav navbar-nav navbar-right">
<li><a href="index.html">Home</a></li>
<li><a href="#about">About</a></li>
<li><a href="#portfolio">Portfolio</a></li>
<li><a href="#products">Products</a></li>
<li><a href="#team">Our Team</a></li>
<li><a href="#video">Video</a></li>
<li><a href="#contact">Contact</a></li>
<li><a href="pages.html">Fishing</a></li>
</ul>
</div>

</div>
</nav>
<!-- Navbar End -->
<!-- Slider Container Start -->
<div class="container-fluid bg-0">
<div class="row">
<div class="col-sm-12">
    <div id="jssor_1" style="position: relative; margin: 0 auto; top: 0px; left: 0px; width: 1300px; height: 500px; overflow: hidden; visibility: hidden;">
        <!-- Loading Screen -->
        <div data-u="loading" style="position: absolute; top: 0px; left: 0px;">
            <div style="filter: alpha(opacity=70); opacity: 0.7; position: absolute; display: block; top: 0px; left: 0px; width: 100%; height: 100%;"></div>
            <div style="position:absolute;display:block;background:url('img/loading.gif') no-repeat center center;top:0px;left:0px;width:100%;height:100%;"></div>
        </div>
        <div data-u="slides" style="cursor: default; position: relative; top: 0px; left: 0px; width: 1300px; height: 500px; overflow: hidden;">
            <div data-p="225.00">
                <img data-u="image" src="<?php echo e(url('images/red.jpg')); ?>" />
                <div style="position: absolute; top: 30px; left: 30px; width: 480px; height: 120px; font-size: 50px; color: #ffffff; line-height: 60px;">TOUCH SWIPE SLIDER</div>
                <div style="position: absolute; top: 300px; left: 30px; width: 480px; height: 120px; font-size: 30px; color: #ffffff; line-height: 38px;">Build your slider with anything, includes image, content, text, html, photo, picture</div>
                <div data-u="caption" data-t="0" style="position: absolute; top: 120px; left: 650px; width: 470px; height: 220px;">
                    <img style="position: absolute; top: 0px; left: 0px; width: 470px; height: 220px;" src="<?php echo e(url('images/c-phone-horizontal.png')); ?>" />
                    <div style="position: absolute; top: 4px; left: 45px; width: 379px; height: 213px; overflow: hidden;">
                        <img data-u="caption" data-t="1" style="position: absolute; top: 0px; left: 0px; width: 379px; height: 213px;" src="<?php echo e(url('images/c-slide-1.jpg')); ?>"/>
                        <img data-u="caption" data-t="2" style="position: absolute; top: 0px; left: 379px; width: 379px; height: 213px;" src="<?php echo e(url('images/c-slide-3.jpg')); ?>" />
                    </div>
                    <img style="position: absolute; top: 4px; left: 45px; width: 379px; height: 213px;" src="<?php echo e(url('img/c-navigator-horizontal.png')); ?>" />
                    <img data-u="caption" data-t="3" style="position: absolute; top: 740px; left: 1600px; width: 257px; height: 300px;" src="images/c-finger-pointing.png" />
                </div>
            </div>
            <div data-p="225.00" style="display: none;">
                <img data-u="image" src="<?php echo e(url('images/purple.jpg')); ?>" />
            </div>
            <div data-p="225.00" data-po="80% 55%" style="display: none;">
                <img data-u="image" src="<?php echo e(url('images/blue.jpg')); ?>" />
            </div>
            <a data-u="any" href="http://www.jssor.com" style="display:none">Full Width Slider</a>
        </div>
        <!-- Bullet Navigator -->
        <div data-u="navigator" class="jssorb05" style="bottom:16px;right:16px;" data-autocenter="1">
            <!-- bullet navigator item prototype -->
            <div data-u="prototype" style="width:16px;height:16px;"></div>
        </div>
        <!-- Arrow Navigator -->
        <span data-u="arrowleft" class="jssora22l" style="top:0px;left:8px;width:40px;height:58px;" data-autocenter="2"></span>
        <span data-u="arrowright" class="jssora22r" style="top:0px;right:8px;width:40px;height:58px;" data-autocenter="2"></span>
    </div>


</div>

</div>

</div>

<!-- End Slider Container End -->
<!-- First Container Start -->
<div class="container-fluid bg-1 text-center" id="about">
<h3 class="margin">Who am I</h3>
<img src="<?php echo e(url('images/bird.jpg')); ?>" class="img-responsive img-circle margin" style="display:inline" alt="King Fisher" width="350" height="350"/>
<h3>I'm a King Fisher</h3>
</div>
<!-- First Container End -->

<!-- Second Container Start -->

<div class="container-fluid bg-2 text-center" id="portfolio">
<h3 class="margin">About us</h3>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>

<a href="#" class="btn btn-default btn-lg">
<span class="glyphicon glyphicon-search"></span>

</a>

</div>

<!-- Second Container End -->

<!-- Third Container Start -->

<div class="container-fluid bg-3 text-center" id="products">
<h3 class="margin"> What About Fish</h3>
<div class="row">
<div class="col-sm-4">
 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
 <img src="<?php echo e(url('images/bird.jpg')); ?>" class="img-reesponsive margin" style="width:100%" alt="image"/>

</div>

<div class="col-sm-4">
 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
 <img src="<?php echo e(url('images/samon.jpg')); ?>" class="img-reesponsive margin" style="width:100%" alt="image"/>

</div>
<div class="col-sm-4">
 <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
 <img src="<?php echo e(url('images/Clock-Hd-Wallpaper.jpg')); ?>" class="img-reesponsive margin" style="width:100%" alt="image"/>

</div>
</div>

</div>

<!-- Third Container End -->

<!-- Fourth Container Start -->

<div class="container-fluid bg-4 text-center" id="team">

<div class="row">
<div class="col-sm-3">
<img src="images/New folder/88wer.jpg" class="img-responsive img-rounded margin" style="width:100%"/>
<p>Mr. Jonson</p>
</div>
<div class="col-sm-3">
<img src="images/New folder/galapagos-eco-fishing.jpg" class="img-responsive img-rounded margin" style="width:100%"/>
<p>Mr. Thomson</p>
</div>
<div class="col-sm-3">
<img src="images/New folder/imasssges.jpg" class="img-responsive img-rounded margin" style="width:100%"/>
<p>Mr. Jefarson</p>
</div>
<div class="col-sm-3">
<img src="images/New folder/ricky_big_catch_h copy.jpg" class="img-responsive img-rounded margin" style="width:100%"/>
<p>Mr. Fishre Man</p>
</div>

</div>

</div>


<!-- Fourth Container End -->

<!-- Sixth Container Start -->
<div class="container-fluid bg-6 text-center" id="video">
<div class="row">
<div class="col-sm-6">
<p>Samlon Fish Catching</p>
<div class="embed-responsive embed-responsive-4by3">
<iframe width="560" height="315" src="https://www.youtube.com/embed/J5wbQS1UPiQ" frameborder="0" allowfullscreen></iframe>
</div>
</div>

<div class="col-sm-6">
<p>Toona Fish Catching</p>
<div class="embed-responsive embed-responsive-4by3">
<iframe width="560" height="315" src="https://www.youtube.com/embed/brYtzCSrfEg" frameborder="0" allowfullscreen></iframe>
</div>
</div>

</div>

</div>

<!-- Sixth Container End -->


<!-- Fifth Container Start -->
<div class="container-fluid bg-5" id="contact">
<div class="row">
<div class="col-sm-4 text-left">
<h4>Copyright(C)Fisherman Developed by IDB Students</h4>

</div>
<div class="col-sm-8 text-right">
<a class="btn btn-social-icon btn-facebook">
<span class="fa fa-facebook"></span>

</a>
<a class="btn btn-social-icon btn-twitter">
<span class="fa fa-twitter"></span>

</a>

<a class="btn btn-social-icon btn-danger">
<span class="fa fa-youtube"></span>

</a>
<a class="btn btn-social-icon btn-linkedin">
<span class="fa fa-linkedin"></span>

</a>

</div>

</div>

</div>
<a id="back-to-top" href="#" class="btn btn-primary btn-lg back-to-top" role="button" title="Click to return on the top page" data-toggle="tooltip" data-placement="left"><span class="glyphicon glyphicon-chevron-up"></span></a>

<!-- Fifth Container End -->


</body>
</html>




<!--<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

         Fonts 
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

         Styles 
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="flex-center position-ref full-height">
            <?php if(Route::has('login')): ?>
                <div class="top-right links">
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(url('/home')); ?>">Home</a>
                    <?php else: ?>
                        <a href="<?php echo e(url('/login')); ?>">Login</a>
                        <a href="<?php echo e(url('/register')); ?>">Register</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="content">
                <div class="title m-b-md">
                    WPSI Round29
                </div>

                <div class="links">
                    <a href="https://codeigniter.com">Codeigniter</a>
                    <a href="https://jquery.com">Jquery</a>
                    <a href="https://php.com">PHP</a>
                    <a href="https://mysql.com">MySql</a>
                    <a href="https://facebook.com">Facebook</a>
                </div>
            </div>
        </div>
    </body>
</html>-->
