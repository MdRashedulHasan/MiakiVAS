<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading">Post <?php echo e($post->id); ?></div>
                    <div class="panel-body">

                        <a href="<?php echo e(url('/posts')); ?>" title="Back"><button class="btn btn-warning btn-xs"><i class="fa fa-arrow-left" aria-hidden="true"></i> Back</button></a>
                        <a href="<?php echo e(url('/posts/' . $post->id . '/edit')); ?>" title="Edit Post"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </button></a>
                        <?php echo Form::open([
                            'method'=>'DELETE',
                            'url' => ['posts', $post->id],
                            'style' => 'display:inline'
                        ]); ?>

                            <?php echo Form::button('<i class="fa fa-trash-o" aria-hidden="true"></i> ', array(
                                    'type' => 'submit',
                                    'class' => 'btn btn-danger btn-xs',
                                    'title' => 'Delete Post',
                                    'onclick'=>'return confirm("Confirm delete?")'
                            )); ?>

                        <?php echo Form::close(); ?>

                        <br/>
                        <br/>

                        <div class="table-responsive">
                            <table class="table table-borderless">
                                <tbody>
                            <tr>
                             <th>ID</th>
                             <td><?php echo $post->id; ?></td>
                            </tr>
                            <tr>
                            <th> Title </th>
                            <td> <?php echo $post->title; ?> </td>
                            </tr>
                            <tr>
                            <th> Category </th>
                            <td> <?php echo $post->category; ?> </td>
                            </tr>
                            <tr>
                            <th> Partner </th>
                            <td> <?php echo $post->partner; ?> </td>
                            </tr>
                            <tr>
                            <th> Description </th>
                            <td> <?php echo $post->description; ?> </td>
                            </tr>
                            <tr>
                            <th> Published </th>
                            <td> <?php echo $post->published; ?> </td>
                            </tr>
                            <tr>
                            <th> Featured </th>
                            <td> <?php echo $post->featured; ?> </td>
                            </tr>
                            <tr>
                            <th> Price </th>
                            <td> <?php echo $post->price; ?> </td>
                            </tr>
                            <tr>
                            <th> Discount </th>
                            <td> <?php echo $post->discount; ?> </td>
                            </tr>
                            <tr>
                            <th> Image </th>                            
                            <!-- <td><?php echo $post->thumbnail; ?></td> -->
                            <td>
                                <td><?php echo Html::image('uploadthumb/'.$post->thumbnail,'alt',array('width'=>150,'height'=>150)); ?></td>
                            </td>
                            </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>