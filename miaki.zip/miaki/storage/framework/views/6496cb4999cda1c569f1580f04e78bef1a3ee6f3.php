<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-heading postsposition">
                    <?php echo Form::select('category', ['Select status', 'Yes', 'No'], null, ['class' => '']); ?>

                    </div>
                    <div class="panel-body">
                        <a href="<?php echo e(url('/posts/create')); ?>" class="btn btn-primary btn-sm" title="Add New Post">
                            <i class="fa fa-plus" aria-hidden="true"></i> New
                        </a>

                    

                        <?php echo Form::open(['method' => 'GET', 'url' => '/posts', 'class' => 'navbar-form navbar-right', 'role' => 'search']); ?>

                        <div class="input-group">
                            <input type="text" class="form-control" name="search" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="submit">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <?php echo Form::close(); ?>


                        <br/>
                        <br/>
                        <div class="table-responsive">
                            <table class="table table-borderless">

                                <thead style="background-color: #F5F5F5">
                                    <tr>
                                        <th>#</th>
                                        <th>Title</th>
                                        <th>Category</th>
                                        <th>Partner</th>
                                        <th>Price</th>
                                        <th>Discount</th>
                                        <th>Status</th>
                                        <th>Featured</th>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php echo e($i=1); ?>

                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($item->title); ?></td>
                                <td><?php echo e($item->category); ?></td>
                                <td><?php echo e($item->partner); ?></td>
                                <td><?php echo e($item->price); ?></td>
                                <td><?php echo e($item->discount); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td><?php echo e($item->featured); ?></td>
                                        <td>
                                            <a href="<?php echo e(url('/posts/' . $item->id)); ?>" title="View Post"><button class="btn btn-info btn-xs"><i class="fa fa-eye" aria-hidden="true"></i> </button></a>
                                            <a href="<?php echo e(url('/posts/' . $item->id . '/edit')); ?>" title="Edit Post"><button class="btn btn-primary btn-xs"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> </button></a>
                                            <?php echo Form::open([
                                                'method'=>'DELETE',
                                                'url' => ['/posts', $item->id],
                                                'style' => 'display:inline'
                                            ]); ?>

                                                <?php echo Form::button('<i class="glyphicon glyphicon-remove" aria-hidden="true"></i> ', array(
                                                        'type' => 'submit',
                                                        'class' => 'btn btn-danger btn-xs',
                                                        'title' => 'Delete Post',
                                                        'onclick'=>'return confirm("Are you sure want to delete this?")'
                                                )); ?>

                                            <?php echo Form::close(); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </tbody>
                            </table>
                            <div class="pagination-wrapper"> <?php echo $posts->appends(['search' => Request::get('search')])->render(); ?> </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>