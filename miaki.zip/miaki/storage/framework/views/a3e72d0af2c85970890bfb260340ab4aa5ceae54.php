<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/jquery.dataTables.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/jquery.dataTables.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>


<div class="container">
    <div class="row">
        <div class="col-sm-12"> 
<?php echo Form::open(['route'=>'attcont.store']); ?>

<table class="table table-bordered">
    <tr>
        <td>
            Employee ID:
        </td>
        <td>
            <?php echo Form::text('emp_id', null,array('class'=>'form-control')); ?>

        </td>
    </tr>
    <tr>
        <td>
            Name:
        </td>
        <td>
            <?php echo Form::text('emp_name', null,array('class'=>'form-control')); ?>

        </td>
    </tr>
    <tr>
        <td>
            Date:
        </td>
        <td>
            <?php echo Form::text('att_date', null,array('class'=>'form-control')); ?>

        </td>
    </tr>
    <tr>
        <td>
            Sign In:
        </td>
        <td>
            <?php echo Form::text('sign_in', null,array('class'=>'form-control')); ?>

        </td>
    </tr>
    <tr>
        <td>
            Sign Out:
        </td>
        <td>
            <?php echo Form::text('sign_out', null,array('class'=>'form-control')); ?>

        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            <?php echo Form::submit('save', null,array('class'=>'btn btn-info')); ?>

        </td>
    </tr>
</table>
<?php echo Form::close(); ?>

        </div>
    </div>
</div>