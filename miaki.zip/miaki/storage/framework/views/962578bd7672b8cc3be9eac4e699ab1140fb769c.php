
<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title>BANGLA TRAC miaki VAS</title>
<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

</head>
<body background="images/background2.png">
<div class="container">
	<div class="row">
		<div class="col-lg-12">
<div class="mycontent alert alert-info">
<h1>BANGLA TRAC miaki VAS:</h1>
<h2>Assignment [Laravel, MySQL,Bootstrap] >> 
<a href="posts" class="btn btn-primary">Click Me!</a>
</h2>
</div>
		</div>
	</div>
	
</div>
</body>
</html>