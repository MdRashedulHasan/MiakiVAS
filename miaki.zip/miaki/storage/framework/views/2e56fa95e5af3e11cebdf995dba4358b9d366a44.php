<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/jquery.dataTables.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/jquery.dataTables.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
	<button data-toggle="modal" data-target="#add_user" class="btn btn-primary">Add+ </button>
<a href="create_myuser" class="btn btn-primary">Create New User</a>
<a href="empAttV" class="btn btn-info">Employee Attendance</a>
<table class="table table-stiped mydatatable">
	<?php echo e($i=1); ?>

	<thead>
		<tr>
			<th>SI</th>
			<th>User Name</th>
			<th>Password</th>
			<th>Delete</th>
			<th>Update</th>
			<th>View</th>
		</tr>
	</thead>
	
	<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($row->myuser_name); ?></td>
			<td><?php echo e($row->myuser_pass); ?></td>
			<td>
				<?php echo Form::open([
					'method'=>'DELETE',
					'route'=>['mycontroller.destroy',$row->id]

				]); ?>


				<?php echo Form::submit('Delete',['class'=>'btn btn-danger btn-sm']); ?>

				
				<?php echo Form::close(); ?>

			</td>
			<td><a href="<?php echo e(route ('mycontroller.edit',$row->id)); ?>" class="btn btn-info btn-sm">Edit</a></td>
			<td><a href="" class="btn btn-success btn-sm">Details</a></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
		</div>
	</div>
</div>

<div id="add_user" class="modal fade" role="dialog">
	<div class="modal-dialog modal-md">
	<?php echo Form::open(array('method'=>'post','id'=>'save')); ?>

		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<table class="table table-hover" id="view_user">
					<tr>
						<th>User Name:</th>
						<td>
							<?php echo Form::text('myuser_name','',array('class'=>'form-control','id'=>'myuser_name','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)')); ?>

						</td>
					</tr>
					<tr><td></td><td id="myuser_name_error" style="color: red"></td></tr>
					<tr>
						<th>User Password:</th>
						<td>
							<?php echo Form::text('myuser_pass','',array('class'=>'form-control','id'=>'myuser_pass','onkeyup'=>'formValidation(id)','onchange'=>'formValidation(id)')); ?>

						</td>
					</tr>
					<tr><td></td><td id="myuser_pass_error" style="color: red"></td></tr>
				</table>
			</div>
			<div class="modal-footer">
				<?php echo Form::submit('Save',array('class'=>'btn btn-success btn-sm','onclick'=>'save_data()')); ?>

				<?php echo Form::button('Cancel',array('class'=>'btn btn-danger btn-sm','data-dismiss'=>'modal')); ?>

			</div>
		</div>
		<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		<?php echo Form::close(); ?>

	</div>
</div>

</body>
<script>
    window.Laravel = <?php echo json_encode([
        'csrfToken' => csrf_token(),
    ]); ?>
</script>
<script type="text/javascript">
function save_data(){
	var form=$('#save').get(0);
	var myuser_name=$('input[name=myuser_name]').val();
	var myuser_pass=$('input[name=myuser_pass]').val();
	var token=$('input[name=_token]').val();

	if(myuser_name==""||myuser_pass==""){
		if(myuser_name==""){
			$('#myuser_name_error').html("Please enter your user name");
			$('#myuser_name').css('border-color','red');
		}
		if(myuser_pass==""){
			$('#myuser_pass_error').html("Please enter your password");
			$('#myuser_pass').css('border-color','red');
		}
	}else{
		$.ajax({
			url:'user_save',
			method:'post',
			data:{
				'myuser_name':myuser_name,
				'myuser_pass':myuser_pass,
				'_token':token
			},
			dataType:'JSON',
			success:function(data){
				$('#add').modal('hide');
				$('#view_user').html(data);
			}
		})
	}
}

function formValidation(id){
	var val=$.trim($('#'+id).val());
	if(val===''){
		$('#'+id+'_error').html('');
		$('#'+id).css('border-color','red');
	}else{
		$('#'+id+'_error').html('');
		$('#'+id).css('border-color','green');
	}
};


	$(document).ready(function(){
		$('.mydatatable').DataTable();
	})
</script>