<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/jquery.dataTables.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/jquery.dataTables.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
<a href="create_att" class="btn btn-primary">Create New Attendance</a>
<a href="myuser" class="btn btn-info">Users</a>
<table class="table table-stiped mydatatable">
	<?php echo e($i=1); ?>

	<thead>
		<tr>
			<th>SI</th>
			<th>Emp ID</th>
			<th>Name</th>
			<th>Date</th>
			<th>SignIn</th>
			<th>SignOut</th>
			<th>Delete</th>
			<th>Update</th>
			<th>View</th>
		</tr>
	</thead>
	
	<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($row->emp_id); ?></td>
			<td><?php echo e($row->emp_name); ?></td>
			<td><?php echo e($row->att_date); ?></td>
			<td><?php echo e($row->sign_in); ?></td>
			<td><?php echo e($row->sign_out); ?></td>
			<td>
				<?php echo Form::open([
					'method'=>'DELETE',
					'route'=>['attcont.destroy',$row->id]

				]); ?>


				<?php echo Form::submit('Delete',['class'=>'btn btn-danger btn-sm']); ?>

				
				<?php echo Form::close(); ?>

			</td>
			<td><a href="<?php echo e(route ('attcont.edit',$row->id)); ?>" class="btn btn-info btn-sm">Edit</a></td>
			<td><a href="" class="btn btn-success btn-sm">Details</a></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
		</div>
	</div>
</div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('.mydatatable').DataTable();
	})
</script>