<!DOCTYPE html>
<html>
	<head>
		<title>Laravel Image Upload with Validation</title>
		<link rel="stylesheet" href="http://www.w3schools.com/lib/w3.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="w3-card-4 w3-sand" style="width:100%;margin-top:50px;">
	        <div class=" w3-padding-64" style="margin-left: 200px;width:50%;">
	            <?php if(count($errors) > 0): ?>
					<div class="alert alert-danger">
						<ul>
							<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
								<li><?php echo e($error); ?></li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
						</ul>
					</div>
				<?php endif; ?>
				<?php if($message = Session::get('success')): ?>
					<div class="alert alert-success alert-block">
						<button type="button" class="close" data-dismiss="alert">�</button>
						<strong><?php echo e($message); ?></strong>
					</div>
					<div class="row">
						<div class="col-md-6">
							<strong>Original Image:</strong>
							<br/>
							<img src="<?php echo e(Session::get('imagePath')); ?>">
						</div>
						<div class="col-md-6">
							<strong>Thumbnail Image:</strong>
							<br/>
							<img src="<?php echo e(Session::get('thumbnailImagePath')); ?>">
						</div>
					</div>
				<?php endif; ?>
	            <form role="form" action="<?php echo e(url('thumbnail')); ?>" method="post" enctype="multipart/form-data">
	                <?php echo e(csrf_field()); ?>

	                <table class="table">
	                    <tr>
	                        <td>
	                            <div class="form-group">
	                            <label for="thumbnail">Select File</label>
	                        </td>
	                        <td>:</td>
	                        <td><input type="file" id="thumbnail" name="thumbnail"></div></td>
	                    </tr>
	                        
	                    <tr>
	                        <td></td>
	                        <td></td>
	                        <td><button type="submit" class="w3-btn w3-brown">Upload</button></td>
	                    </tr>
	                </table>
	            </form>
	        </div>
	    </div>
	</body>
</html>