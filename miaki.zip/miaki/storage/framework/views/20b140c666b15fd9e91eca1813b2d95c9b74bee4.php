<?php echo Html::style('/css/bootstrap.min.css'); ?>

<?php echo Html::style('/css/jquery.dataTables.min.css'); ?>

<?php echo Html::script('/js/jquery-1.11.3.min.js'); ?>

<?php echo Html::script('/js/jquery.dataTables.min.js'); ?>

<?php echo Html::script('/js/bootstrap.min.js'); ?>

<body>
<div class="container">
	<div class="row">
		<div class="col-sm-12">
<a href="create_myuser" class="btn btn-primary">Create New User</a>
<a href="empAttV" class="btn btn-info">Employee Attendance</a>
<table class="table table-stiped mydatatable">
	<?php echo e($i=1); ?>

	<thead>
		<tr>
			<th>SI</th>
			<th>User Name</th>
			<th>Password</th>
			<th>Delete</th>
			<th>Update</th>
			<th>View</th>
		</tr>
	</thead>
	
	<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
			<td><?php echo e($i++); ?></td>
			<td><?php echo e($row->myuser_name); ?></td>
			<td><?php echo e($row->myuser_pass); ?></td>
			<td>
				<?php echo Form::open([
					'method'=>'DELETE',
					'route'=>['mycontroller.destroy',$row->id]

				]); ?>


				<?php echo Form::submit('Delete',['class'=>'btn btn-danger btn-sm']); ?>

				
				<?php echo Form::close(); ?>

			</td>
			<td><a href="<?php echo e(route ('mycontroller.edit',$row->id)); ?>" class="btn btn-info btn-sm">Edit</a></td>
			<td><a href="" class="btn btn-success btn-sm">Details</a></td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>
		</div>
	</div>
</div>
</body>
<script type="text/javascript">
	$(document).ready(function(){
		$('.mydatatable').DataTable();
	})
</script>